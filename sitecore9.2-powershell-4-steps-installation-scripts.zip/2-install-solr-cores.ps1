#define parameters
$prefix = "sc"
$PSScriptRoot = "C:\Sitecore92\"
$SolrUrl = "https://localhost:8983/solr"
$SolrRoot = "C:\Sitecore9\Solr\solr-7.5.0"
$SolrService = "Solr"


#install solr cores for xdb
$solrParams = @{
    Path = "$PSScriptRoot\xconnect-solr.json"
    SolrUrl = $SolrUrl
    SolrRoot = $SolrRoot
    SolrService = $SolrService
    CorePrefix = $prefix
   }
Install-SitecoreConfiguration @solrParams

#install solr cores for sitecore
$solrParams = @{
 Path = "$PSScriptRoot\sitecore-solr.json"
 SolrUrl = $SolrUrl
 SolrRoot = $SolrRoot
 SolrService = $SolrService
 CorePrefix = $prefix
}
Install-SitecoreConfiguration @solrParams
