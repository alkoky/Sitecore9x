#define parameters
$prefix = "sc"
$PSScriptRoot = "d:\Sitecore92\"
$XConnectCollectionService = "$($Prefix)xconnect"
$SolrUrl = "https://localhost:8983/solr"
$SqlServer = "(local)"
$SqlAdminUser = "sa"
$SqlAdminPassword="SomePassword"


#install client certificate for xconnect
$certParams = @{
  CertificateName = "$prefix.xconnect_client"
}
Install-SitecoreConfiguration @certParams -Verbose
#deploy xconnect instance
$xconnectParams = @{
 Path = "$PSScriptRoot\xconnect-xp0.json"
 Package = "$PSScriptRoot\Sitecore 9.2.0 rev. 002893 (OnPrem)_xp0xconnect.scwdp.zip"
 LicenseFile = "$PSScriptRoot\license.xml"
 Sitename = $XConnectCollectionService
 XConnectCert = $certParams.CertificateName
 SqlDbPrefix = $prefix
 SqlServer = $SqlServer
 SqlAdminUser = $SqlAdminUser
 SqlAdminPassword = $SqlAdminPassword
 SolrCorePrefix = $prefix
 SolrURL = $SolrUrl

}
Install-SitecoreConfiguration @xconnectParams

